#ifndef WDT_H
#define WDT_H

#include <avr/io.h>

// We have to define our own constants to match the
// bit patterns for the various timeouts in the WDTCSR 
// register.

// Timeout macros.
#define wdtTO_16MS 0
#define wdtTO_32MS 1
#define wdtTO_64MS 2
#define wdtTO_125MS 3
#define wdtTO_250MS 4
#define wdtTO_500MS 5
#define wdtTO_1S 6
#define wdtTO_2S 7
#define wdtTO_4S 32
#define wdtTO_8S 33

// Watchdog modes.
#define wdtMode_Off (0 << WDE)|(0 << WDIE)|(0 << WDCE)
#define wdtMode_Reset (1 << WDE)
#define wdtMode_Interrupt (1 << WDIE)|(1 << WDIF)
#define wdtMode_ResetInterrupt (1 << WDE)|(1 << WDIE)|(1 << WDIF)

// Special timed sequence.
#define wdtTimed (1<<WDCE) | (1<<WDE)

// Functions in the library.
#ifdef __cplusplus
  extern "C" {
    void wdtReset();
    void wdtDisable();
    void wdtEnable(uint16_t param);
  }
#endif //__cplusplus

#endif // WDT_H
