#! /bin/bash

# This simple script converts the Markdown file into
# PDF and HTML using Pandoc.
#
# Norman Dunbar.
# 15 August 2025.
#
pandoc --from markdown --to pdf --output LM75A_Lib.pdf --table-of-contents --number-sections --top-level-division=section LM75A_Lib.md 

pandoc --from markdown --to html5 --output LM75A_Lib.html --table-of-contents --number-sections --top-level-division=section LM75A_Lib.md 

