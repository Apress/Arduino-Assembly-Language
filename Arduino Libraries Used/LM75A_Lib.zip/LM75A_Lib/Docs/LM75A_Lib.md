# LM75A_LIB - an LM75A library for Assembly Language

This library allows the Assembly Language developer the ability to communicate easily with an LM75A temperature sensor.

**WARNING**: The library is intended to be installed into the Arduino IDE, but is only for use with Assembly Language sketches. It cannot be used with C or C++ sketches in its current form. It is also not suitable for use with _normal_ assemblers as it uses instructions specific to the GCC _avr-as_ assembler. Why GCC had to make life different is beyond me!


## Dependencies

This library sits on top of the I2C_ASM library which communicates with I2C devices.


## Mode of Operation

All the functions within the library, unless otherwise specified, return with the Z flag set to indicate success. The R24 register will be returned holding the status code from any of the I2C operations that took place.

## Definitions and Macros

The following macros are defined in the header file _LM75A_Lib.h_:

* LM75A Registers:
    * LM75A_TEMPERATURE_REG - Current temperature register. Read only.
    * LM75A_CONFIG_REG - The configuration register. Read/Write.
    * LM75A_T_HYST_REG - The Hysteresis register. Read/Write.
    * LM75A_T_OS_REG - The alarm temperature register. Read/Write.
    * LM75A_PRODUCT_ID_REG - The Product ID. Read only.

* LM75A Fault Counts:
    * LM75A_FAULTS_1 - Sets fault count in config to 1.
    * LM75A_FAULTS_2 - Sets fault count in config to 2.
    * LM75A_FAULTS_4 - Sets fault count in config to 4.
    * LM75A_FAULTS_6 - Sets fault count in config to 6.

* LM75A OS Pin Polarity:
    * LM75A_OS_POLARITY_LOW - OS pin is active low.
    * LM75A_OS_POLARITY_HIGH - OS pin is active high.

* LM75A OS Pin Modes:
    * LM75A_COMPARATOR_MODE - OS pin is in comparator mode.
    * LM75A_INTERRUPT_MODE - OS pin is in interrupt mode.

* LM75A Shutdown (low power) Settings
    * LM75A_SHUTDOWN_ENABLE - low power.shutdown mode enabled.
    * LM75A_SHUTDOWN_DISABLE - low power/shutdown mode disabled.


## Function List

The following functions are provided by the library:

* LM75AInit - Initialises the LM75A.
* LM75Areset - Resets the LM75A back to register 0, the current temperature register. Not likely to be of much use, but used internally.
* getCurrentTemperature - returns the current temperature in degrees C.
* getOSTemp - Returns the alarm/overheat temperature in degrees C.
* setOSTemp - Sets the alarm/overheat temperature in degrees C.
* resetOSTemp - Resets the alarm/overheat temperature back to power on default - 80 degrees C.
* getOSHyst - Returns the Hysteresis temperature in degrees C.
* setOSHyst - Sets the Hysteresis temperature in degrees C.
* resetOSHyst - Resets the Hysteresis temperature back to power on default - 75 degrees C.
* getConfig - Returns the current configuration state of the LM75A.
* setConfig - Sets the current configuration state of the LM75A.
* setConfig - Resets the current configuration state of the LM75A.
* setFaults - Sets the fault counter.
* setPolarity - Sets the polarity of the OS pin's active state.
* setInterrupt - Sets interrupt mode.
* setComparator - Sets comparator mode.
* setShutdown - Sets the shutdown (aka low power) mode of the LM75A.
* getProductID - Returns the product ID for Texas Instruments (genuine) LM75A devices.

## Functions

### LM75AInit

Initialises the LM75A. Stores the sensor's address for later use.  
**NOTE**: Only one temperature sensor can be used at a time. 

The function expects the 7 bit address of the sensor to be supplied. This will be stored internally to the library and will be used until the next call to this function with a new address.

**NOTE**: Do not supply the 8 bit addresses for read and/or write. The parameter must be the 7 bit address.

#### Input Parameters

* R24: The sensors 7 bit address.

#### Returns

* Z set to indicate success, it does not fail!

---

### LM75Areset

May be used to reset the LM75A's default read register back to the current temperature register, if you have managed to change it somehow by directly fiddling with I2C and not using the library functions! (Wink!)

This function resets the current register back to register 0, which is the current temperature register.

#### Input Parameters

* None.

#### Returns

* R24: set to the I2C status byte if errors detected, preserved otherwise.
* Z set to indicate success, clear otherwise.

---

### getCurrentTemperature

#### Input Parameters

* X: Pointer to a two byte (at least) buffer where the two temperature bytes will be placed. The first byte is the temperature in degrees. The top bit, bit 7, of the second byte will be clear for decimal zero temperature fractions; and set for decimal 5 degree fractions.

Temperatures are always x.0 or x.5 degrees C.

#### Returns

* X: Preserved. Points at the start of the data buffer.
* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### getOSTemp

Returns the OS Temperature. This defaults to 80 degrees C at power on but may be changed with _setOSTemp_ and reset to default with _resetOSTemp_. The LM75A can be configured to set its OS pin high or low as required, when the temperature exceeds this setting.

#### Input Parameters

* None.

#### Returns

* R24: set to the current OS Temperature setting.
* Z set to indicate success, clear otherwise.

---

### setOSTemp

Returns the OS Temperature. Only exact degrees C can be set with this function.

#### Input Parameters

* R24: Data byte representing the new value for this setting.

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### resetOSTemp

Returns the OS Temperature to power on default of 80 degrees C.


#### Input Parameters

* None.

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### getOSHyst

Returns the Hysteresis temperature.  This defaults to 75 degrees C at power on but may be changed with _setOSHyst_ and reset to default with _resetOSHyst_. This setting defines the temperature below which any over temperature states will be reset. An alarm state exists when the temperature exceeds the OS Temperature.

#### Input Parameters

* None.

#### Returns

* R24: The current Hysteresis Temperature; or the status byte on error.
* Z set to indicate success, clear otherwise.

---

### setOSHyst

Sets the Hysteresis Temperature in whole degrees C.

#### Input Parameters

* R24: The new value for the Hysteresis Temperature setting.

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### resetOSHyst

Returns the Hysteresis Temperature to power on default of 80 degrees C.


#### Input Parameters

* None.

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### getConfig

#### Input Parameters

Returns the current configuration byte. The format is:

* Bits 7-5: Always zero.
* Bits 4-3: Fault counter. Actual fault counts are:
    * 00 - 1 fault.
    * 01 - 2 faults.
    * 10 - 4 faults.
    * 11 - 6 faults.
* Bit 2: OS Polarity. 0 = Active low; 1 = active high.
* Bit 1: Comparator/Interrupt mode. 0 = Comparator; 1 = Interrupt.
* Bit 0: Low power/shutdown mode. 0 = normal; 1 = low power/shutdown.

The configurations bits define how the LM75A should act under certain conditions. 

* Fault Counter - used to delay the activation of the OS pin. It will not activate until it has seen the number of over temperature readings specified in the fault counter. The data sheet's naming leaves a lot to be desired!
* OS Polarity - Defines if the OS pin will be active low or active high. This pin requires a 10 K pullup resistor if used.
* Comparator mode - In this mode, the default, the OS pin will be active whenever the current temperature rises above that set in OS Temperature; and inactive when the current temperature drops below the Hysteresis Temperature setting.
* Interrupt mode - In this mode, the OS pin will be active briefly whenever the current temperature rises above that set in OS Temperature; and also, when it drops below that set in the Hysteresis temperature. 
* Low power/shutdown mode - In this mode, the device is not actually shutdown, contrary to the naming convention used in the data sheet, but is simply put into a power saving mode.

#### Returns

* Z set to indicate success, clear otherwise.

---

### setConfig

Sets the configuration byte to the value passed as a parameter. This configures all parts of the LM75A in one operation.

#### Input Parameters

* R24: The new configuration byte. 

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### resetConfig

Resets the configuration to the power on default state. (All bits zero) which configures:

* OS Temperature: 80 C.
* Hysteresis temperature: 75 C.
* OS Active low.
* Comparator mode.
* Register 0, the current temperature, is the default read register.

#### Input Parameters

* None.

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### setFaults

Changes the fault count part of the configuration to that specified as the parameter.

#### Input Parameters

* R24: The new fault count which must be one of:
    * LM75A_FAULTS_1
    * LM75A_FAULTS_2
    * LM75A_FAULTS_4
    * LM75A_FAULTS_6
    
Invalid settings will be masked and adjusted so may not have the desired effect.
    

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### setPolarity

Changes the OS Polarity part of the configuration to that specified as the parameter.

#### Input Parameters

* R24: The new polarity setting which must be one of:
    * LM75A_OS_POLARITY_LOW
    * LM75A_OS_POLARITY_HIGH
    
Invalid settings will be masked and adjusted so may not have the desired effect.

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### setInterrupt

Sets the LM75A into Interrupt mode. OS will go active when the current temperature rises above TEMP_OS and *remain set indefinitely*. However, reading from the LM75A or setting shutdown will clear the OS pin back to inactive.


#### Input Parameters

* None.
    
#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### setComparator

Sets the LM75A into Comparator mode. OS will go active when the current temperature rises above TEMP_OS and inactive when it drops below TEMP_HYST.  Unlike Interrupt mode, the OS pin will reset when the temperature drops below TEMP_HYST.


#### Input Parameters

* None.
    
#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### setShutdown

Sets the LM75A into or out of "shutdown" mode. This is what the data sheet refers to for some reason, it simply puts the sensor into a low power mode.

#### Input Parameters

* R24: The new shutdown mode setting which must be one of:
    * LM75A_SHUTDOWN_ENABLE
    * LM75A_SHUTDOWN_DISABLE

#### Returns

* R24: Status byte.
* Z set to indicate success, clear otherwise.

---

### getProductID

Reads the product ID byte from the LM75A. Texas Instruments supplied LM75As have a product ID of 0xAr where the 'r' part of the hexadecimal number represents the release number.

Other LM75As simply return 0xFF for this function.

#### Input Parameters

* None.

#### Returns

* R24: Product ID byte; status byte on error.
* Z set to indicate success, clear otherwise.


