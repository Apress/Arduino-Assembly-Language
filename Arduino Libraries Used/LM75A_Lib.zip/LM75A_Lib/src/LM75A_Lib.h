#ifndef LM75A_LIB_H
#define LM75A_LIB_H

#include <I2C_ASM.h>

// LM75A Registers.
#define LM75A_TEMPERATURE_REG   0
#define LM75A_CONFIG_REG        1
#define LM75A_T_HYST_REG        2
#define LM75A_T_OS_REG          3
#define LM75A_PRODUCT_ID_REG    7


// LM75A Configuration bits.

// Fault counts. How many faults before OS output pin is active?
#define LM75A_FAULTS_1			0 << 3
#define LM75A_FAULTS_2			1 << 3
#define LM75A_FAULTS_4			2 << 3
#define LM75A_FAULTS_6			3 << 3

// OS pin polarity. Active high or low?
#define LM75A_OS_POLARITY_LOW	0 << 2
#define LM75A_OS_POLARITY_HIGH	1 << 2

// Comparator or interrupt mode for OS?
#define LM75A_COMPARATOR_MODE	0 << 1
#define LM75A_INTERRUPT_MODE 	1 << 1

// Shutdown settings.
#define LM75A_SHUTDOWN_ENABLE 	1 << 0
#define LM75A_SHUTDOWN_DISABLE  0 << 0

#endif // LM75A_LIB_H
