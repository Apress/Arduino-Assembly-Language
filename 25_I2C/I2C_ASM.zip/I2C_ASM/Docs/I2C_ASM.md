# I2C_ASM - an I2C library for Assembly Language

This library allows the Assembly Language developer the ability to communicate relatively easily with various I2C enabled sensors. 

**WARNING**: The library is intended to be installed into the Arduino IDE, but is only for use with Assembly Language sketches. It cannot be used with C or C++ sketches in its current form. It is also not suitable for use with _normal_ assemblers as it uses instructions specific to the GCC _avr-as_ assembler. Why GCC had to make life different is beyond me!


## Dependencies

This library is fully self contained and has no dependencies. It is, however, a dependency for the LM75A_Lib library,..


## Mode of Operation

All the functions within the library, unless otherwise specified, return with the Z flag set to indicate success. The R24 register will be returned holding the status code from any of the I2C operations that took place.

## Definitions and Macros

The following macros are defined in the header file _I2C_ASM.h_:

* I2C Clock Frequencies:
    * TWI2C_100KHZ - Sets the SCL frequency to 100 KHz.
    * TWI2C_200KHZ - Sets the SCL frequency to 200 KHz.
    * TWI2C_400KHZ - Sets the SCL frequency to 400 KHz.
    * TWI2C_1MHZ - Sets the SCL frequency to 1 MHz.
    
* I2C Clock Prescaler:
    * TWI2C_PS_Div1 - Sets the prescaler to divide by 1. This is the only prescaler advised by the data sheet.
    
* I2C Commands:
    * TWI2C_START - Used to send a start to the I2C bus. 
    * TWI2C_STOP - Used to send a stop to the I2C bus.
    * TWI2C_SLAR - Used to send the SLA_R address to the bus.
    * TWI2C_SLAW - Used to seld the SLA_W addrrss to the bus.
    * TWI2C_READ_ACK - Used to request a read from the sensor with an ACK returned.
    * TWI2C_READ_NACK - Used to request a read fropm the sensort with a NACK returned.
    * TWI2C_WRITE - Used to request a write to the sensor.
    
* I2C Status Codes
    * Common to Controller transmitter and receiver modes.
        * TWI2C_START_SENT - the previous operation sucessfully sent a start.
        * TWI2C_REPEATED_START_SENT - the previous operation sucessfully sent a repeated start.
        * TWI2C_ARBITRATION_LOST - Arbitration has been lost, the bus has been dropped.
    * Controller transmitter mode:
        * TWI2C_SLAW_SENT_ACK_RCVD - SLA_W was sent and a sensor returned an ACK.
        * TWI2C_SLAW_SENT_NACK_RCVD - SLA_W was sent and a NACK was returned.
        * TWI2C_DATA_SENT_ACK_RCVD - A data byte was sent and an ACK was returned.
        * TWI2C_DATA_SENT_NACK_RCVD - A data byte was sent and a NACK was returned.
    * Controller Receiver:
        * TWI2C_SLAR_SENT_ACK_RCVD - SLA_R was sent and a sensor returned an ACK.
        * TWI2C_SLAR_SENT_NACK_RCVD - SLA_R was sent and a NACK was returned.
        * TWI2C_DATA_RCVD_ACK_SENT - A data byte was read and an ACK was returned.
        * TWI2C_DATA_RCVD_NACK_SENT - A data byte was read and a NACK was returned.
    * Other status codes:
        * TWI2C_BUS_ERROR - an I2C bus error has been detected.
        * TWI2C_NO_STATUS_INFO - Operation still in progress no valid status code yet.

## Function List

The following functions are provided by the library:

* twi2c_init - Initialises the I2C bus and clock frequency. Pulls up SDA and SCL.
* twi2c_begin_tx - Begins a transaction which writes to a sensor or device.
* twi2c_begin_rx - Begins a transaction which reads from a sensor or device.
* twi2c_end_tx - Ends a write (or read) transaction.
* twi2c_end_rx - Ends a read (or write) transaction.
* twi2c_read_ack - Reads a single data byte and returns an ACK to the sensor.
* twi2c_read_nack - Reads a single data byte and returns a NACK to the sensor.
* twi2c_write_ack - Writes a data byte to the sensor or device, and expects an ACK to be returned.
* twi2c_check_status  Waits for the current action to complete, returns the status of that action.
* twi2c_read_data - Reads multiple bytes, returns ACK for all but the last which gets a NACK.
* twi2c_write_data - Writes multiple bytes, expects an ACK for all bytes written.

## Functions

### twi2c_init

Initialises the I2C bus by setting the SCL clock frequency to one of 100, 200 or 400 KHz; or 1 MHz.

The function expects the `TWBR` value to be passed in `R24` to set the clock frequency.

#### Input Parameters

* R24: The I2C clock frequency setting.

#### Returns

* None. This always works.

---

### twi2c_begin_tx

This function will begin a write transaction by sending a start condition to the bus, followed by SLA_W address for the desired sensor or device that the controller wishes to write to. The 7 bit address of the sensor is expected to be passed in `R24`.

This function may block if the bus is already in use.

On a successful execution, the Arduino will be in Controller Transmitter mode.

#### Input Parameters

* R24: The sensor's 7 bit address. The function handles converting it to SLA_W.

#### Returns

* R24: The I2C status byte for SLA_W write operation, but may contain an error from the start attempt if that failed for some reason.
* All other registers are preserved.
* Z set to indicate success, clear otherwise.

---

### twi2c_begin_rx

This function will begin a read transaction by sending a start condition to the bus, followed by SLA_R address for the desired sensor or device that the controller wishes to read from. The 7 bit address of the sensor is expected to be passed in `R24`.

This function may block if the bus is already in use.

On a successful execution, the Arduino will be in Controller Receiver mode.

#### Input Parameters

* R24: The sensor's 7 bit address. The function handles converting it to SLA_R.

#### Returns

* R24: The I2C status byte for SLA_R write operation, but may contain an error from the start attempt if that failed for some reason.
* All other registers are preserved.
* Z set to indicate success, clear otherwise.

---

### twi2c_end_tx and twi2c_end_rx

These two functions simply end a transaction. You may wish to call either, regardless of the transaction in operation as they both call the same internal function and simply send a stop condition to the bus.

Stopping the bus does not return any status codes---it is assumed to always work.

#### Input Parameters

* None.

#### Returns

* None.
* All registers are preserved.

---

### twi2c_read_ack

Reads one byte from the transmitter device. On completion, returns an ACK to the transmitter. You would normally call this function to read all but the final byte of a transmission. The last byte would then be read with `twi2c_read_nack`.

#### Input Parameters

* None.

#### Returns

* R24: Status byte.
* R25: Data byte read from the transmitter.
* All other registers are preserved.
* Z set to indicate success, clear otherwise.

---

### twi2c_read_nack

Reads one byte from the transmitter device. On completion, returns a NACK to the transmitter. You would normally call this function to read the final byte of a transmission. The other bytes would already have been read with `twi2c_read_ack`.


#### Input Parameters

* None.

#### Returns

* R24: Status byte.
* R25: Data byte read from the transmitter.
* All other registers are preserved.
* Z set to indicate success, clear otherwise.

---

### twi2c_write_ack

Writes a single byte to the receiver and expects to receive an ACK back from it.

#### Input Parameters

* R24: The data byte to be written..

#### Returns

* R24: Status byte.
* R25: Data byte read from the transmitter.
* All other registers are preserved.
* Z set to indicate success, clear otherwise.

---

### twi2c_check_status

Waits for the current operation, if one is in progress, to complete. Returns the status byte for the most recent operation. This function will set the Z flag if the value passed in as the expected status code, matches the actual status code.

If no expected status byte is supplied, Z will be clear (unless the random data in `R24` matches the actual status of course). In all cases, the actual status will be returned.

#### Input Parameters

* R24: The expected status code for the most recent operation.

#### Returns

* R24: The actual status byte for the most recent operation.
* All other registers are preserved.
* Z set if actual status matches expected status, clear otherwise.

---

### twi2c_read_data

Reads a given number of data bytes from the transmitter. Stores all received bytes in a buffer supplied by the calling code. Reads all but the final byte and returns an ACK. The final byte is read but a NACK is returned.

In the event that zero bytes are requested, the function will return with Z set to indicate success. If, at any point while reading, an error occurs, the function will return before completion with the status byte returned.


#### Input Parameters

* R24: The desired number of bytes to be read from the transmitter.
* X: The address of the buffer, which must be large enough to hold all the bytes specified by `R24`.

#### Returns

* R24: Status byte.
* X: Preserved. The address of the buffer.
* All other registers are preserved.
* Z set to indicate success, clear otherwise.

---

### twi2c_write_data

Writes a given number of data bytes to the receiver. All bytes written expect an ACK to be returned.

In the event that zero bytes are requested, the function will return with Z set to indicate success. If, at any point while writing data, an error occurs, the function will return before completion with the status byte returned.


#### Input Parameters

* R24: The desired number of bytes to be written to the receiver.
* X: The address of the buffer, which must be large enough to hold all the bytes specified by `R24`.

#### Returns

* R24: Status byte.
* X: Buffer address of the next byte to be sent. (X on entry + R24 on entry + 1).
* All other registers are preserved.
* Z set to indicate success, clear otherwise.


