#! /bin/bash

# This simple script converts the Markdown file into
# PDF and HTML using Pandoc.
#
# Norman Dunbar.
# 15 August 2025.
#
pandoc --from markdown --to pdf --output I2C_ASM.pdf --table-of-contents --number-sections --top-level-division=section I2C_ASM.md 

pandoc --from markdown --to html5 --output I2C_ASM.html --table-of-contents --number-sections --top-level-division=section I2C_ASM.md 

