#ifndef I2C_ASM_H
#define I2C_ASM_H

#include <avr/io.h>

// I2C Configuration settings.
// Clock frequencies.
#define TWI2C_100KHZ 72     // 100 KHz SCL clock rate.
#define TWI2C_200KHZ 32     // 200 KHz SCL clock rate.
#define TWI2C_400KHZ 12     // 400 KHz SCL clock rate.
#define TWI2C_1MHZ    0     // 1 MHz SCL clock rate.

// Prescaler. Data sheet says leave at divide by 1.
#define TWI2C_PS_Div1 		(1<<TWPS1)|(1<<TWPS0)

// I2C "Commands", settings for TWCR in polling mode.
#define TWI2C_START 		(1<<TWINT)|(1<<TWSTA)|(1<<TWEN)
#define TWI2C_STOP  		(1<<TWINT)|(1<<TWSTO)|(1<<TWEN)
#define TWI2C_SLAR  		(1<<TWINT)|(1<<TWEN)
#define TWI2C_SLAW  		(1<<TWINT)|(1<<TWEN)
#define TWI2C_READ_ACK  	(1<<TWINT)|(1<<TWEA)|(1<<TWEN)
#define TWI2C_READ_NACK 	(1<<TWINT)|(1<<TWEN)
#define TWI2C_WRITE 		(1<<TWINT)|(1<<TWEN)

// I2C Status codes.
// Common to Controller Transmitter and Receiver.
#define TWI2C_START_SENT 			0x08
#define TWI2C_REPEATED_START_SENT 	0x10
#define TWI2C_ARBITRATION_LOST 		0x38

// Controller Transmitter
#define TWI2C_SLAW_SENT_ACK_RCVD 	0x18
#define TWI2C_SLAW_SENT_NACK_RCVD 	0x20
#define TWI2C_DATA_SENT_ACK_RCVD 	0x28
#define TWI2C_DATA_SENT_NACK_RCVD 	0x30

// Controller Receiver.
#define TWI2C_SLAR_SENT_ACK_RCVD 	0x40
#define TWI2C_SLAR_SENT_NACK_RCVD 	0x48
#define TWI2C_DATA_RCVD_ACK_SENT 	0x50
#define TWI2C_DATA_RCVD_NACK_SENT 	0x58

// Peripheral Transmitter &
// Peripheral Receiver status codes are not used here.

// Other status codes.
#define TWI2C_BUS_ERROR 			0x00
#define TWI2C_NO_STATUS_INFO 		0xF8

#endif  // I2C_ASM_H
